import java.util.Scanner;
import static java.lang.Math.abs;

public class Main {
    public static void main(String[] args) {

        // Задание 1
        Scanner scr1 = new Scanner(System.in);
        System.out.println("Введите первое число ");
        double m = scr1.nextDouble();
        System.out.println("Введите второе число ");
        double n = scr1.nextDouble();
        System.out.println((abs(m) - 10) >= (abs(n) - 10) ? "Число " + m + " ближе к 10" : "Число " + n + " ближе к 10");


        // Задание 2
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое однозначное число:");
        int num1 = scr.nextInt();
        System.out.println("Введите второе однозначное число:");
        int num2 = scr.nextInt();
        System.out.println("Умножте эти два числа и ответ запишите");
        int num3 = scr.nextInt();
        if ((num1 * num2) != num3) {
            System.out.println("Вы ввели неправильный ответ. Правильный ответ " + (num1 * num2));
        }

        // Задание 3
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите год");
        int year = scn.nextInt();
        if (year <= 1977) {
            System.out.println(year < 1935 ? "Элвис еще не родился" : "Элвис жив!");
        }
        if (year > 1977) {
            System.out.println("Элвис навсегда в наших сердцах!");
        }
    }
}