import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scr = new Scanner(System.in);
        System.out.println("Введите STONE, PAPER, SCISSORS");
        String user = scr.nextLine();
        Game userChoice = Game.valueOf(user.toUpperCase(Locale.ROOT));

        int comp = new Random().nextInt(3);
        Game compChoice = switch (comp) {
            case 0 -> Game.STONE;
            case 1 -> Game.PAPER;
            default -> Game.SCISSORS;
        } ;
        System.out.println("Выбор компьютера " + compChoice);
        if (userChoice == compChoice) {
            System.out.println("Ничья!");
            return;
        }
        if (userChoice == Game.STONE && compChoice == Game.SCISSORS
        || userChoice == Game.PAPER && compChoice == Game.STONE
        || userChoice == Game.SCISSORS && compChoice == Game.PAPER) {
            System.out.println("Победил пользователь!");
        } else {
            System.out.println("Победил компьютер!");
        }

    }
}