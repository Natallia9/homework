public enum Game {
    STONE,
    SCISSORS,
    PAPER,
}
