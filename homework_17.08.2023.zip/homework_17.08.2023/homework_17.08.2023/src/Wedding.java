public enum Wedding {
    CHINTZ,
    PAPER,
    LEATHER,
    lINEN,
    WOODEN,
    COST_IRON,
    COPPER,
    TIN,
    FAIENCE,
    OLOVIANNAJA,
    }

