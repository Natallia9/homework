import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Задание 1

        Scanner scr = new Scanner(System.in);
        System.out.println("Сколько лет вы находитесь в браке?");
        int user = scr.nextInt();

        Wedding wed = switch (user) {
            case 1 -> Wedding.CHINTZ;
            case 2 -> Wedding.PAPER;
            case 3 -> Wedding.LEATHER;
            case 4 -> Wedding.lINEN;
            case 5 -> Wedding.WOODEN;
            case 6 -> Wedding.COST_IRON;
            case 7 -> Wedding.COPPER;
            case 8 -> Wedding.TIN;
            case 9 -> Wedding.FAIENCE;
            default -> Wedding.OLOVIANNAJA;
        };
        if (user == 0) {
            System.out.println("Следующая годовщина свадьбы - Ситцевая");
            return;
        }
        if (user == 1) {
            System.out.println(wed + " Следующа годовщина свадьбы - Бумажная");
            return;
        }
        if (user == 2) {
            System.out.println(wed + " Следующа годовщина свадьбы - Кожаная");
            return;
        }
        if (user == 3) {
            System.out.println(wed + " Следующа годовщина свадьбы - Льняная");
            return;
        }
        if (user == 4) {
            System.out.println(wed + " Следующа годовщина свадьбы - Деревянная");
            return;
        }
        if (user == 5) {
            System.out.println(wed + " Следующа годовщина свадьбы - Чугунная");
            return;
        }
        if (user == 6) {
            System.out.println(wed + " Следующа годовщина свадьбы - Медная");
            return;
        }
        if (user == 7) {
            System.out.println(wed + " Следующа годовщина свадьбы - Жестяная");
            return;
        }
        if (user == 8) {
            System.out.println(wed + " Следующа годовщина свадьбы - Фаянсовая");
            return;
        }
        if (user == 9) {
            System.out.println(wed + " Следующа годовщина свадьбы - Оловянная");
            return;
        }
        if (user > 10) {
            System.out.println("Больше дат нет");
        }


    }

}

