
public class Main {
    public static void main(String[] args) {

        // Задание 1

        int result1 = multiplication(7, 15);
        int result2 = multiplication(7, 10, 15);
        int result3 = multiplication(5, 8, 10, 15);

        System.out.println("Результат умножения двух чисел " + result1);
        System.out.println("Результат умножения трех чисел " + result2);
        System.out.println("Результат умножения четырех чисел " + result3);

    }

    public static int multiplication(int a, int b) {
        return a * b;
    }

    public static int multiplication(int a, int b, int c) {
        int number2 = multiplication(a, b);
        return number2 * c;
    }

    public static int multiplication(int a, int b, int c, int d) {
        int number3 = multiplication(a, b, c);
        return number3 * d;
    }
}

