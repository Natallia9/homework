import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {

        // Задание 3

        int[] array = new int[8];
        Random random = new Random();
        for (int i = 0; i < 8; i++) {
            array[i] = random.nextInt(50) + 1;
        }
        System.out.println("Массив " + Arrays.toString(array));

        for (int i = 1; i < 8; i += 2) {
            array[i] = 0;
        }
        System.out.println("Массив после замены " + Arrays.toString(array));

        Arrays.sort(array);

        System.out.println("Массив после сортировки " + Arrays.toString(array));

        // Задание 4

        String[] string = {
                "В некоторых книгах слишком много правды. В других - слишком мало лжи.",
                "Там, где начинается любовь, кончаются Свет и Тьма.",
                "Благо общее и благо конкретное редко встречаются вместе.",
                "Самое страшное в войне - понять врага.",
                "Вечная женская манера: задавать каждый вопрос в двух-трех вариациях."
        };

        String shortLine = string[0];
        String longLine = string[0];

        for (String str : string) {
            if (str.length() < shortLine.length()) {
                shortLine = str;
            }
            if (str.length() > longLine.length()) {
                longLine = str;
            }
        }
        System.out.println("Массив строк:");
        for (String str : string) {
            System.out.println(str);
        }

        System.out.println("Строка с наименьшей длиной: " + shortLine);
        System.out.println("Строка с наибольшей длиной: " + longLine);


    }
}