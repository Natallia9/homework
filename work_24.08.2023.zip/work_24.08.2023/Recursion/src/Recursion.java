import java.util.Scanner;
// Задание 2

public class Recursion {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите число ");
        int n = scanner.nextInt();

        long factorial = factorial(n);
        System.out.println("Факториал " + n + " равен " + factorial);
    }

    public static long factorial(int n) {
        if (n == 1) {
            return 1;
        } else {
            return factorial(n - 1) * n;
        }
    }
}