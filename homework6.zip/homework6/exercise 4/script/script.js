let image = [
    "https://w.forfun.com/fetch/2c/2c38ec7c72e3d0094f591d6f735a3b8e.jpeg",
    "https://mobimg.b-cdn.net/v3/fetch/b3/b3bfbbd7d636148f68451e3eba8884d4.jpeg",
    "https://mykaleidoscope.ru/x/uploads/posts/2022-10/1666112530_27-mykaleidoscope-ru-p-milie-kartinki-krasivo-31.jpg",
    "https://pichold.ru/wp-content/uploads/2018/12/1453029571_1450750653_1-31.jpg"
];

let cards = document.getElementById('card');
let large = document.getElementById('large');
let imageLarge = document.getElementById('image-large');
for (let i = 0; i < image.length; i++) {
    let gallery = document.createElement("img");
    gallery.src = image[i];
    gallery.className = "gallery";
    cards.appendChild(gallery);
    gallery.addEventListener('click', function() {
        imageLarge.src = image[i];
        large.style.display = 'block';
    });
}

