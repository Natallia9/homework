let container = document.getElementById("cards");
    for (let i = 0; i < 10; i++) {
      let card = document.createElement("div");
          card.classList.add("card");
          card.textContent = i;

          card.addEventListener('click', function() {
            this.classList.toggle('active');
            });

            container.appendChild(card);
        }
