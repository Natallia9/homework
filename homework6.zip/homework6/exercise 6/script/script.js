const words = [
    { ru: "получать", en: "get" },
    { ru: "место", en: "place" },
    { ru: "сделать", en: "made" },
    { ru: "жить", en: "live" },
    { ru: "после", en: "after" }
  ];

  const box = document.getElementById("container");

        for (let i = 0; i < words.length; i++) {
            const word = words[i];
            
            const card = document.createElement("div");
            card.className = "card";
            
            const ru = document.createElement("p");
            ru.className = "russian";
            ru.textContent = word.ru;
            card.appendChild(ru);

            const en = document.createElement("p");
            en.className = "english";
            en.textContent = word.en;
            card.appendChild(en);
            box.appendChild(card);
        }

        const buttonRus = document.getElementById("rus");
        const buttonEng = document.getElementById("eng");

        buttonRus.addEventListener("click", () => {
        toggleLanguage("russian");
        });

        buttonEng.addEventListener("click", () => {
            toggleLanguage("english");
        });
        
        function toggleLanguage(language) {
            const cards = document.querySelectorAll(".card");
        
            cards.forEach((card) => {
                const parRus = card.querySelector(".russian");
                const parEng = card.querySelector(".english");
        
                if (language === "russian") {
                    parRus.classList.add("displayed");
                    parEng.classList.remove("displayed");
                } else if (language === "english") {
                    parRus.classList.remove("displayed");
                    parEng.classList.add("displayed");
                }
            });
        }