const container = document.getElementById("container");

for (let i = 0; i <= 255; i += 5) {
  let background = document.createElement("div");
  background.className = "box";
  let color = `rgb(128, 128, ${i})`;
  background.style.backgroundColor = color;
  container.appendChild(background);
}