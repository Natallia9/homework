const words = [
    { ru: "получать", en: "get" },
    { ru: "место", en: "place" },
    { ru: "сделать", en: "made" },
    { ru: "жить", en: "live" },
    { ru: "после", en: "after" }
  ];

  const box = document.getElementById("container");

        for (let i = 0; i < words.length; i++) {
            const word = words[i];
            
            const card = document.createElement("div");
            card.className = "card";
            
            const ru = document.createElement("p");
            ru.className = "russian";
            ru.textContent = word.ru;
            card.appendChild(ru);

            const en = document.createElement("p");
            en.className = "english";
            en.textContent = word.en;
            card.appendChild(en);

            card.addEventListener("click", () => {
                ru.classList.toggle("russian");
                ru.classList.toggle("english");
                en.classList.toggle("russian");
                en.classList.toggle("english");
            });

            box.appendChild(card);
        }

        
