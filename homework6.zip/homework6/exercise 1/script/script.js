// Задание 1

let array = ["Параграф_1", "Параграф_2", "Параграф_3"];
let element = document.querySelector('div');
for (let i = 0; i < array.length; i++) {
    let paragraph = document.createElement('p');
    paragraph.textContent = array[i];
    element.append(paragraph);
}
let paragraphs = document.querySelectorAll('p');

paragraphs.forEach(function (paragraph) {
    paragraph.addEventListener("click", function () {
        paragraph.textContent = "********";
    });
});

