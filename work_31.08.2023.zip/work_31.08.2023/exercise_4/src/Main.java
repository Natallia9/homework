public class Main {
    public static void main(String[] args) {

        String str = "AAAABBBCCCDDEG";
        System.out.println(str);

        collapse(str);
    }

    public static void collapse(String folding) {

            StringBuilder rolled = new StringBuilder();
            char word = folding.charAt(0);
            int number = 1;
            for (int i = 1; i < folding.length(); i++) {
                if (folding.charAt(i) == word) {
                    number++;
                } else {
                    rolled.append(word);
                    rolled.append(number);
                    word = folding.charAt(i);
                    number = 1;
                }
            }
            System.out.println(rolled);
        }

    }
