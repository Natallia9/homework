import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Задание 1
        char[][] alph = new char[4][10];
        char let = 'А';
        char previous = alph[0][0];
        for (int i = 0; i < alph.length; i++) {
            for (int j = 0; j < alph[i].length; j++) {
                if (previous != 'Е') {
                    alph[i][j] = let;
                    let++;
                } else {
                    alph[i][j] = 'Ё';
                }
                previous = alph[i][j];
                if (alph[i][j] == 'Я') break;
            }
        }
        System.out.println(Arrays.deepToString(alph));


        // Задание 2

        Scanner scr = new Scanner(System.in);

        System.out.println("Введите первое слово с четным количеством символов: ");
        String word1 = scr.next();

        System.out.println("Введите второе слово с четным количством символов: ");
        String word2 = scr.next();

        if (word1.length() % 2 == 0 && word2.length() % 2 == 0) {
            String sub1 = word1.substring(0, word1.length() / 2);
            String sub2 = word2.substring(word2.length() / 2);
            String result = sub1 + sub2;
            System.out.println("Получилось слово - " + result);
        }

        // Задание 3

        String str = new String("I study Basic Java!");
        System.out.println(str);

        char last = str.charAt(str.length() - 1);
        System.out.println("Выводит последний символ строки " + last);

        boolean substring = str.contains("Java");
        System.out.println("Строка содержит подстроку Java " + substring);

        String rpl = str.replace('a', 'o');
        System.out.println("Строка после замены a на o " + rpl);

        String upper = str.toUpperCase();
        System.out.println("Строка приведена в верхний регистр " + upper);

        String lower = str.toLowerCase();
        System.out.println("Строка приведена в нижний регистр " + lower);

        int start = str.indexOf("Java");
        int end = start + "Java".length();
        if (start != -1) {

            String cut = str.substring(start, end);
            System.out.println("Строка после вырезания 'Java': " + cut);


        }
    }
}


