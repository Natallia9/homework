import java.time.DayOfWeek;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Задание 1

        System.out.println("Объявлен сбор денег ко Дню рождения на новый компьютер");
        int suma = 0;
        while (suma <= 10000) {
            int friend = new Random().nextInt(5);
            suma += switch (friend) {
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                default -> 500;
            };
            System.out.println("Собранная сумма составляет " + suma + " долларов");
        }
        System.out.println("Необходимая сумма составила " + suma + " долларов");
        System.out.println("Приглашаю всех в ресторан выпить за мое здоровье!");

        // Задание 2

        Scanner sc = new Scanner(System.in);
        do {
            Scanner scr = new Scanner(System.in);
            System.out.println("Введите первое число");
            int num1 = scr.nextInt();
            System.out.println("Введите второе число");
            int num2 = scr.nextInt();
            int sum = 0;
            for (int i = Math.min(num1, num2); i <= Math.max(num1, num2); i = i + 2) {
                sum += i;
                System.out.println("Сумма введенных чисел равна " + sum);
            }
            System.out.println("Для выхода введите quite");
        }
        while (!"quite".equalsIgnoreCase(sc.nextLine())); {
            System.out.println("Программа выполнена");
        }

        // Задание 3

        Scanner scan = new Scanner(System.in);
        System.out.println("Введите день недели ");
        String week = scan.nextLine();
        DayOfWeek user = DayOfWeek.valueOf(week.toUpperCase(Locale.ROOT));

        for (java.time.DayOfWeek i : java.time.DayOfWeek.values()) {
            if (i == user) {
                continue;
            }
            System.out.println(i.ordinal() + " " + i.name() + " ");
        }

    }
}














