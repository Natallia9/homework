import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Задание 1

        Random rnd = new Random();
        int length = rnd.nextInt();
        System.out.println(length + " м");
        length *= 0.001;
        System.out.println(length + " км");
        length *= 0.621;
        System.out.println(length + " миль");
        length *= 5280;
        System.out.println(length + " фут");
        length *= 0.428;
        System.out.println(length + " аршин");

        // Задание 2

        Scanner scr = new Scanner(System.in);
        System.out.println("Ввести сумму стоимости товара: ");
        float price = scr.nextFloat();
        System.out.println("Ввести сумму покупателя: ");
        float amountOfMoney = scr.nextFloat();
        float change = amountOfMoney - price;
        int rub = (int) (change % 100);
        int kop = (rub % 10);
        System.out.println("Сдача составляет:" + rub + " руб." + kop + " коп.");


                // Задание 3
        boolean isYearFinished = true;
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean camping = (isYearFinished ^ isGoodWeather) && (hasBoughtRaincoats || isGoodWeather) &&(isJimFree ^ hasKateComeBack);
        System.out.println(camping);

              // Задание 4
        Scanner scr1 = new Scanner(System.in);
        System.out.println("Введите целое число:");
        int num1 = scr1.nextInt();
        int num2 = num1 >> 1;
        System.out.println("Ваше число деленное на 2 составляет: " + num2);

        // Задание от 03.08.2023
        int i = 234;
        int a = (i / 100);
        int b = (i / 10 % 10);
        int c = (i % 10);
        System.out.println(a + "," + b + "," + c);

    }
}