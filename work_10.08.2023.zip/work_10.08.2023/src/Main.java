import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Задание 1

        Scanner length = new Scanner(System.in);
        System.out.println("Ввести значение в метрах:");
        double m = length.nextFloat();
        double km = m * 0.001;
        System.out.println(km + " км");
        double mi = m * 0.000621371;
        System.out.println(mi + " миль");
        double ft = m * 3.28;
        System.out.println(ft + " фут");
        double ar = m * 1.406;
        System.out.println(ar + " аршин");

        // Задание 2

        Scanner scr = new Scanner(System.in);
        System.out.println("Ввести сумму стоимости товара: ");
        float price = scr.nextFloat();
        System.out.println("Ввести сумму покупателя: ");
        float amountOfMoney = scr.nextFloat();
        float change = amountOfMoney - price;
        int rub = (int) (change * 100);
        int change2 = (rub / 100);
        int change3 = (rub % 100);
        System.out.println("Сдача: " + change2 + " руб. " + change3 + " коп.");


                // Задание 3
        boolean isYearFinished = true;
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean camping = (isYearFinished) && (hasBoughtRaincoats || isGoodWeather) && (isJimFree ^ hasKateComeBack);
        System.out.println(camping);

              // Задание 4
        Scanner scr1 = new Scanner(System.in);
        System.out.println("Введите целое число:");
        int num1 = scr1.nextInt();
        int num2 = num1 >> 1;
        System.out.println("Ваше число деленное на 2 составляет: " + num2);

        // Задание от 03.08.2023
        int i = 234;
        int a = (i / 100);
        int b = (i / 10 % 10);
        int c = (i % 10);
        System.out.println(a + "," + b + "," + c);

    }
}