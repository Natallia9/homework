import java.util.Random;
import java.util.UUID;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Задание 1
        Random rnd = new Random();
        int xNumber = rnd.nextInt(950);
        System.out.println("Номер " + xNumber);
        float yNumber = rnd.nextFloat(95);
        System.out.println("Номер " + yNumber);
        boolean bNumber = rnd.nextBoolean();
        System.out.println("Вывод " + bNumber);
        double dNumber = rnd.nextDouble();
        System.out.println("Номер " + dNumber);
        long lNumber = rnd.nextLong();
        System.out.println("Номер " + lNumber);
        int i = 256;
        short sNumber= (short) rnd.nextInt(i);
        System.out.println("Номер " + sNumber);
        int r = 123;
        char cNumber = (char) rnd.nextInt(r);
        System.out.println("Номер " + cNumber);

        String str = UUID.randomUUID().toString();
        System.out.println("Строка " + str);
        int i1 = 15;
        String numberLine = String.valueOf(i1);
        System.out.println("Строка - " + numberLine);



        //Задание 2
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите ваше имя: ");
        String name = scr.nextLine();
        System.out.print("Введите ваш возраст: ");
        int age = scr.nextInt();
        System.out.println("Введите ваш вес: ");
        int weight = scr.nextInt();
        System.out.println("Уважаемая " + name + " в свои " + age + " Вы для нас дороги как " + weight + " кг" + " золото!");


        //Задание 3
        Scanner scr1 = new Scanner(System.in);
        System.out.println("Введите первое число:");
        int number1 = scr1.nextInt();
        System.out.println("Введите второе число:");
        int number2 = scr1.nextInt();
        System.out.println("Сумма чисел:" + (number1 + number2));
        System.out.println("Вычитание чисел:" + (number1 - number2));
        System.out.println("Умножение чисел:" + (number1 * number2));
        System.out.println("Деление чисел" + (number1 / number2));





    }
}