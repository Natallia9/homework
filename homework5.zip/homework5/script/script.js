// Задание 1

console.log("старт");

for (let i=1; i<=9; i++) {
  console.log(i);
}

console.log("финиш");

// Задание 2

for (let number=10; number<=99; number++){
  if (number%3==0 && number%5==0) {
    console.log(number);
  }
}
  // Задание 3

 console.log("Введите диапазон чисел");
  let number1=parseInt(prompt("Введите первое число: "));
  let number2=parseInt(prompt("Введите второе число: "));

  let sum=0;

  while(number1<=number2){
    sum+=number1;
    number1++;
  } 
  console.log("Сумма чисел в заданном диапазоне: " + sum);

  // Задание 4

let num=parseInt(prompt("Введите число: "));

let arr = [];
for(let i=1; i<=num; i++){
  if(num%i==0){
    arr.push(i);
  }
}
console.log("Делители этого числа: "+arr);

// Задание 5

console.log("Введите 10 чисел: ");
let user=[];
let tenNum=10;

let positiveNum=0;
let negativeNum=0;
let zeroNum=0;
let evenNum=0;
let oddNum=0;

for(i=0; i<tenNum; i++){
  let userNum = parseInt(prompt(`Введите число ${i + 1}:`));
  user.push(userNum);

  if (userNum > 0) {
    positiveNum++;
  } else if (userNum < 0) {
    negativeNum++;
  } else {
    zeroNum++;
  } 
  if (userNum%2==0){
    evenNum++
  } else {
    oddNum++
  }
  
}

console.log("Введенные числа:", user);
console.log("Количество положительных чисел:", positiveNum);
console.log("Количество отрицательных чисел:", negativeNum);
console.log("Количество нулей:", zeroNum);
console.log("Количество четных чисел:", evenNum);
console.log("Количество нечетных чисел:", oddNum);