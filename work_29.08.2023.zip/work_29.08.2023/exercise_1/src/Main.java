import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        // Задание 1

        LocalDate[] dates = {
                LocalDate.of(2019, 1, 30),
                LocalDate.of(2015, 2, 21),
                LocalDate.of(2007, 3, 8),
                LocalDate.of(2010, 4, 5),
                LocalDate.of(2014, 5, 2),
                LocalDate.of(2022, 6, 17),
                LocalDate.of(2017, 7, 22),
                LocalDate.of(2023, 8, 19),
        };
        for (LocalDate date : dates) {
            System.out.println(date);

        }
    }
}