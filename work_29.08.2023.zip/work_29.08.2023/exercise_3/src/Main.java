import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        // Задание 3
        LocalDate[] dates = {
                LocalDate.of(2019, 1, 30),
                LocalDate.of(2015, 2, 21),
                LocalDate.of(2007, 3, 8),
                LocalDate.of(2010, 4, 5),
                LocalDate.of(2014, 5, 2),
                LocalDate.of(2022, 6, 17),
                LocalDate.of(2017, 7, 22),
                LocalDate.of(2023, 8, 19)
        };
        for (LocalDate date : dates) {
            System.out.println(date);

            dayOfMonth(dates);
        }
    }
    public static void dayOfMonth(LocalDate[] day) {
        for (int i = 1; i < day.length; i++) {
            LocalDate x = day[i];
            int j = i - 1;
            while (j >= 0 && day[j].getDayOfMonth() > x.getDayOfMonth()) {
                day[j + 1] = day[j];
                --j;
            }
            day[j + 1] = x;
        }
    }
}