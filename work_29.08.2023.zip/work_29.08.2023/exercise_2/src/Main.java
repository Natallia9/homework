import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        // Задание 2
        LocalDate[] dates = {
                LocalDate.of(2019, 1, 30),
                LocalDate.of(2015, 2, 21),
                LocalDate.of(2007, 3, 8),
                LocalDate.of(2010, 4, 5),
                LocalDate.of(2014, 5, 2),
                LocalDate.of(2022, 6, 17),
                LocalDate.of(2017, 7, 22),
                LocalDate.of(2023, 8, 19)
        };

        for (LocalDate date : dates) {
            System.out.println(date);

            bubbleYear(dates);
        }
    }
        public static void bubbleYear(LocalDate[] date1) {

        boolean sort = false;
        while (!sort) {
            sort = true;
            for (int i = 1; i < date1.length; i++) {
                if (date1[i - 1].getYear() > date1[i].getYear()) {
                    LocalDate year = date1[i - 1];
                    date1[i - 1] = date1[i];
                    date1[i] = year;
                    sort = false;
                }
            }
        }

    }
}

